import openpyxl
from tkinter import *
from time import sleep
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch
from mpl_toolkits.mplot3d import proj3d
import tkinter as tk
from PIL import ImageTk, Image

color_m='red'
color_0p='grey'
color_3p='orange'
color_5p='green'


def plot(plane,n):
    row=[n for n in range(33) if n>=3]
    plot=Plot()
    pos_ws=[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]]
    
    p0=[[],[],[]]
    p1=[[],[],[]]
    p2=[[],[],[]]
    p3=[[],[],[]]
    p4=[[],[],[]]

    plane = openpyxl.load_workbook('file\\'+str(plane)+'.xlsx')
    plane_0p=plane["0p"]
    plane_3p=plane["3p"]
    plane_5p=plane["5p"]
    for i in row:
        p0[0].append([plane_0p["b"+str(i)].value+pos_ws[0][0],plane_0p["c"+str(i)].value+pos_ws[0][1],plane_0p["d"+str(i)].value+pos_ws[0][2]])
        p1[0].append([plane_0p["e"+str(i)].value+pos_ws[1][0],plane_0p["f"+str(i)].value+pos_ws[1][1],plane_0p["g"+str(i)].value+pos_ws[1][2]])
        p2[0].append([plane_0p["h"+str(i)].value+pos_ws[2][0],plane_0p["i"+str(i)].value+pos_ws[2][1],plane_0p["j"+str(i)].value+pos_ws[2][2]])
        p3[0].append([plane_0p["k"+str(i)].value+pos_ws[3][0],plane_0p["l"+str(i)].value+pos_ws[3][1],plane_0p["m"+str(i)].value+pos_ws[3][2]])
        p4[0].append([plane_0p["n"+str(i)].value+pos_ws[4][0],plane_0p["o"+str(i)].value+pos_ws[4][1],plane_0p["p"+str(i)].value+pos_ws[4][2]])

        p0[1].append([plane_3p["b"+str(i)].value+pos_ws[0][0],plane_3p["c"+str(i)].value+pos_ws[0][1],plane_3p["d"+str(i)].value+pos_ws[0][2]])
        p1[1].append([plane_3p["e"+str(i)].value+pos_ws[1][0],plane_3p["f"+str(i)].value+pos_ws[1][1],plane_3p["g"+str(i)].value+pos_ws[1][2]])
        p2[1].append([plane_3p["h"+str(i)].value+pos_ws[2][0],plane_3p["i"+str(i)].value+pos_ws[2][1],plane_3p["j"+str(i)].value+pos_ws[2][2]])
        p3[1].append([plane_3p["k"+str(i)].value+pos_ws[3][0],plane_3p["l"+str(i)].value+pos_ws[3][1],plane_3p["m"+str(i)].value+pos_ws[3][2]])
        p4[1].append([plane_3p["n"+str(i)].value+pos_ws[4][0],plane_3p["o"+str(i)].value+pos_ws[4][1],plane_3p["p"+str(i)].value+pos_ws[4][2]])

        p0[2].append([plane_5p["b"+str(i)].value+pos_ws[0][0],plane_5p["c"+str(i)].value+pos_ws[0][1],plane_5p["d"+str(i)].value+pos_ws[0][2]])
        p1[2].append([plane_5p["e"+str(i)].value+pos_ws[1][0],plane_5p["f"+str(i)].value+pos_ws[1][1],plane_5p["g"+str(i)].value+pos_ws[1][2]])
        p2[2].append([plane_5p["h"+str(i)].value+pos_ws[2][0],plane_5p["i"+str(i)].value+pos_ws[2][1],plane_5p["j"+str(i)].value+pos_ws[2][2]])
        p3[2].append([plane_5p["k"+str(i)].value+pos_ws[3][0],plane_5p["l"+str(i)].value+pos_ws[3][1],plane_5p["m"+str(i)].value+pos_ws[3][2]])
        p4[2].append([plane_5p["n"+str(i)].value+pos_ws[4][0],plane_5p["o"+str(i)].value+pos_ws[4][1],plane_5p["p"+str(i)].value+pos_ws[4][2]])

    plane.close()
    
    if n==0:    plot.plot_p(p0[0],p0[1],p0[2])
    if n==1:    plot.plot_p(p1[0],p1[1],p1[2])
    if n==2:    plot.plot_p(p2[0],p2[1],p2[2])
    if n==3:    plot.plot_p(p3[0],p3[1],p3[2])
    if n==4:    plot.plot_p(p4[0],p4[1],p4[2])

    plt.show()
    



def interface():
    w=Tk()
    w.title("Plot degli errori")
    w.geometry('1200x755')
    w.columnconfigure(0, weight=1)
    w.columnconfigure(1, weight=3)
    w.configure(background="#254117")
    w.resizable=(False,False)

    xy_label = Label(w, text='Piano\nxy', pady=0,fg="white",bg="#254117",width=20,height=2,font=('',16))
    xy_label.grid(row=2,column=0,padx=20,pady=10,rowspan=5)
    xy_button = Button(w, text='marker 1', command=lambda:plot('xy',0), pady=0,fg="white",bg="#254117",width=50,height=1)
    xy_button.grid(row=2,column=1,padx=20,pady=5)
    xy_button = Button(w, text='marker 2', command=lambda:plot('xy',1), pady=0,fg="white",bg="#254117",width=20,height=1)
    xy_button.grid(row=3,column=1,padx=20,pady=5)
    xy_button = Button(w, text='marker 3', command=lambda:plot('xy',2), pady=0,fg="white",bg="#254117",width=20,height=1)
    xy_button.grid(row=4,column=1,padx=20,pady=5)
    xy_button = Button(w, text='marker 4', command=lambda:plot('xy',3), pady=0,fg="white",bg="#254117",width=20,height=1)
    xy_button.grid(row=5,column=1,padx=20,pady=5)
    xy_button = Button(w, text='marker 5', command=lambda:plot('xy',4), pady=0,fg="white",bg="#254117",width=20,height=1)
    xy_button.grid(row=6,column=1,padx=20,pady=5)
    label=Label(w,text='--------------------------------------------------------------------------------',fg="white",bg="#254117")
    label.grid(row=7,column=0,padx=5,pady=20,columnspan=2)

    xz_label = Label(w, text='Piano\nxz', pady=0,fg="white",bg="#254117",width=20,height=2,font=('',16))
    xz_label.grid(row=8,column=0,padx=20,pady=10,rowspan=5)
    xz_button = Button(w, text='marker 1', command=lambda:plot('xz',0), pady=0,fg="white",bg="#254117",width=20,height=1)
    xz_button.grid(row=8,column=1,padx=20,pady=5)
    xz_button = Button(w, text='marker 2', command=lambda:plot('xz',1), pady=0,fg="white",bg="#254117",width=20,height=1)
    xz_button.grid(row=9,column=1,padx=20,pady=5)
    xz_button = Button(w, text='marker 3', command=lambda:plot('xz',2), pady=0,fg="white",bg="#254117",width=20,height=1)
    xz_button.grid(row=10,column=1,padx=20,pady=5)
    xz_button = Button(w, text='marker 4', command=lambda:plot('xz',3), pady=0,fg="white",bg="#254117",width=20,height=1)
    xz_button.grid(row=11,column=1,padx=20,pady=5)
    xz_button = Button(w, text='marker 5', command=lambda:plot('xz',4), pady=0,fg="white",bg="#254117",width=20,height=1)
    xz_button.grid(row=12,column=1,padx=20,pady=5)
    label=Label(w,text='----------------------------------------------------------------------------------',fg="white",bg="#254117")
    label.grid(row=13,column=0,padx=5,pady=20,columnspan=2)

    yz_label = Label(w, text='Piano\nyz', pady=0,fg="white",bg="#254117",width=20,height=2,font=('',16))
    yz_label.grid(row=14,column=0,padx=20,pady=10,rowspan=5)
    yz_button = Button(w, text='marker 1', command=lambda:plot('yz',0), pady=0,fg="white",bg="#254117",width=20,height=1)
    yz_button.grid(row=14,column=1,padx=20,pady=5)
    yz_button = Button(w, text='marker 2', command=lambda:plot('yz',1), pady=0,fg="white",bg="#254117",width=20,height=1)
    yz_button.grid(row=15,column=1,padx=20,pady=5)
    yz_button = Button(w, text='marker 3', command=lambda:plot('yz',2), pady=0,fg="white",bg="#254117",width=20,height=1)
    yz_button.grid(row=16,column=1,padx=20,pady=5)
    yz_button = Button(w, text='marker 4', command=lambda:plot('yz',3), pady=0,fg="white",bg="#254117",width=20,height=1)
    yz_button.grid(row=17,column=1,padx=20,pady=5)
    yz_button = Button(w, text='marker 5', command=lambda:plot('yz',4), pady=0,fg="white",bg="#254117",width=20,height=1)
    yz_button.grid(row=18,column=1,padx=20,pady=5)
    label=Label(w,text='----------------------------------------------------------------------------------',fg="white",bg="#254117")
    label.grid(row=7,column=0,padx=5,pady=20,columnspan=2)

    img = Image.open('file\\immagini\\work_space.jpg')
    
    img = img.resize((800, 720), Image.ANTIALIAS)
    img = ImageTk.PhotoImage(img)
    panel = Label(w, image = img)
    panel.grid(row=1,column=2,rowspan=18,padx=20,pady=5)

    w.mainloop()




##############################################################################################################################################
#CLASSE Plot
##############################################################################################################################################
'''descrizione classe Plot: 
    la classe plot permette di visualizzare nello spazio tridimensionale i seguenti elementi:
    -liste di punti: plot_p(lista_punti[x,y,z])
    -piani: plot_plane (lista coeff di definizione del piano [a,b,c,d])
    -terne di trasformazione plot_frame(matrice_di_trasformazione 4X4)
    utilizzo:
    -inizializzare l'oggetto di classe Plot
    -eseguire le procedure necessarie
    -utilizzare il metodo plt.show() per vedere il risultato'''


class Plot:

    #costruttore della classe
    def __init__(self):
        self.ax=plt.axes(projection='3d')
        return None

    #metodo che permette di visualizzare una lista di punti
    def plot_p(self,p0,p1,p2):
        ax=self.ax

        ax.scatter(0, 0, 0, color=color_m, s=7, label='Posizione del marker')
        ax.scatter(p0[0][0], p0[0][1], p0[0][2], color=color_0p, s=2 ,label='Nessuna calibrazione')
        ax.scatter(p1[0][0], p1[0][1], p1[0][2], color=color_3p, s=2 ,label='Calibrazione a 3 punti')
        ax.scatter(p2[0][0], p2[0][1], p2[0][2], color=color_5p, s=2 ,label='Calibrazione a 5 punti')

        for i in [i for i in range(len(p0)) if i>=1]:
            ax.scatter(p0[i][0], p0[i][1], p0[i][2], color=color_0p, s=2)
            ax.scatter(p1[i][0], p1[i][1], p1[i][2], color=color_3p, s=2)
            ax.scatter(p2[i][0], p2[i][1], p2[i][2], color=color_5p, s=2)

        ax.view_init(elev = 5, azim=70)

        ax.legend()
        self.ax.set_xlabel('x [mm]')
        self.ax.set_ylabel('y [mm]')
        self.ax.set_zlabel('z [mm]')
    

##############################################################################################################################################
#MAIN
##############################################################################################################################################
def main():
    interface()
    
if __name__ == '__main__':
    main()
